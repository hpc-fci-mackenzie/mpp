#ifndef BUCKETSORT_H_
#define BUCKETSORT_H_

long int* bucket_sort(char *, int, long int);

#endif /* BUCKETSORT_H_ */
