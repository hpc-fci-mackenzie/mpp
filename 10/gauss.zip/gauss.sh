#$ -S /bin/sh

time ./gauss
