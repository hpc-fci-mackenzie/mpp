#$ -S /bin/sh

time ./quicksort
