#$ -S /bin/sh

time ./tsp
