#$ -S /bin/sh

./smooth
