/**
 * @param argc the argc
 * @param argv the argv
 * @param output the output
 * @param n the size of the probabilities vector
 * @param p the probabilities vector
 */
void obst(int* output,int n,float* p);
