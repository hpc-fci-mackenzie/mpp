/**
 * @param argc the argc
 * @param argv the argv
 * @param input the input n*n long unsigned int matrix
 * @param n the number of matrix rows and columns
 * @param output the output n*n long unsigned int matrix
 */
void component_labeling(int argc,char* argv[],long unsigned int** output,const long unsigned int n,const long unsigned int** input);
