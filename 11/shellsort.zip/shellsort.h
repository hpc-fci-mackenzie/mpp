#ifndef SHELLSORT_H_
#define SHELLSORT_H_

void shell_sort(char *, int, long int);

#endif /* SHELLSORT_H_ */
